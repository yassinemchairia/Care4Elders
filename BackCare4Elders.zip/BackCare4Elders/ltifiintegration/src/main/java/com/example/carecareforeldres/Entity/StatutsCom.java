package com.example.carecareforeldres.Entity;

public enum StatutsCom { EN_ATTENTE,EXPEDIEE
}
