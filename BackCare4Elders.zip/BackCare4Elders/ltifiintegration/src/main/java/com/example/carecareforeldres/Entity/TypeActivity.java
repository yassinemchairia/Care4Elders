package com.example.carecareforeldres.Entity;

public enum TypeActivity {
    ONLINE_FITNESS,
    VIRTUAL_YOGA,
    GUIDED_MEDITATION,
    VIRTUAL_COOKING,
    CONTINUING_EDUCATION,
    VIRTUAL_BOOK_CLUB,
    ONLINE_GAMES
}
