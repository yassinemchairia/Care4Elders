package com.example.carecareforeldres.Entity;

public enum Sexe {
    HOMME,FEMME,AUTRE
}
