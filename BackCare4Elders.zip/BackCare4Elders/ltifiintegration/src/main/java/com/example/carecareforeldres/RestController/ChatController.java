package com.example.carecareforeldres.RestController;

import com.example.carecareforeldres.Entity.Medecin;
import com.example.carecareforeldres.Entity.Message;
import com.example.carecareforeldres.Entity.Patient;
import com.example.carecareforeldres.Repository.MedecinRepository;
import com.example.carecareforeldres.Repository.MessageRepository;
import com.example.carecareforeldres.Repository.PatientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.webjars.NotFoundException;

import java.util.List;

@RestController
@CrossOrigin("*")
@RequestMapping("/chat")

public class ChatController {

    @Autowired
    private MessageRepository messageRepository;
    @Autowired
    private MedecinRepository medecinRepository;
    @Autowired
    private PatientRepository patientRepository;

    // Endpoint pour envoyer un message du médecin au patient
    @PostMapping("/medecin/{idMedecin}/patient/{idPatient}/send")
    public void sendMessageToPatient(@PathVariable Integer idMedecin, @PathVariable Integer idPatient, @RequestBody String contenu) {
        Medecin medecin = medecinRepository.findById(idMedecin).orElseThrow(() -> new NotFoundException("Medecin not found"));
        Patient patient = patientRepository.findById(idPatient).orElseThrow(() -> new NotFoundException("Patient not found"));

        Message message = new Message();
        message.setContenu(contenu);
        message.setMedecin(medecin);
        message.setPatient(patient);

        messageRepository.save(message);
    }

    // Endpoint pour envoyer un message du patient au médecin
    @PostMapping("/patient/{idPatient}/medecin/{idMedecin}/send")
    public void sendMessageToMedecin(@PathVariable Integer idPatient, @PathVariable Integer idMedecin, @RequestBody String contenu) {
        Medecin medecin = medecinRepository.findById(idMedecin).orElseThrow(() -> new NotFoundException("Medecin not found"));
        Patient patient = patientRepository.findById(idPatient).orElseThrow(() -> new NotFoundException("Patient not found"));

        Message message = new Message();
        message.setContenu(contenu);
        message.setMedecin(medecin);
        message.setPatient(patient);

        messageRepository.save(message);
    }

    @GetMapping("/medecin/{idMedecin}/patient/{idPatient}/messages")
    public List<Message> getMessagesFromMedecinToPatient(@PathVariable Integer idMedecin, @PathVariable Integer idPatient) {
        Medecin medecin = medecinRepository.findById(idMedecin).orElseThrow(() -> new NotFoundException("Medecin not found"));
        Patient patient = patientRepository.findById(idPatient).orElseThrow(() -> new NotFoundException("Patient not found"));

        return messageRepository.findByMedecinAndPatient(medecin, patient);
    }

    // Endpoint pour récupérer les messages envoyés par un patient à un médecin
    @GetMapping("/patient/{idPatient}/medecin/{idMedecin}/messages")
    public List<Message> getMessagesFromPatientToMedecin(@PathVariable Integer idPatient, @PathVariable Integer idMedecin) {
        Medecin medecin = medecinRepository.findById(idMedecin).orElseThrow(() -> new NotFoundException("Medecin not found"));
        Patient patient = patientRepository.findById(idPatient).orElseThrow(() -> new NotFoundException("Patient not found"));

        return messageRepository.findByPatientAndMedecin(patient, medecin);
    }

    @GetMapping("/getAllMedecin")
    public List<Medecin> getAllCuisinier() {
        return medecinRepository.findAll();
    }
}
