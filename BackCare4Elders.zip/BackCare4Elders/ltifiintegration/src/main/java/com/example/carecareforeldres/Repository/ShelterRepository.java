package com.example.carecareforeldres.Repository;

import com.example.carecareforeldres.Entity.Shelter;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ShelterRepository extends JpaRepository<Shelter,Long> {
}
