package com.example.carecareforeldres.Repository;

import com.example.carecareforeldres.Entity.Morgue;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MorgueRepository extends JpaRepository<Morgue,Long> {
}
