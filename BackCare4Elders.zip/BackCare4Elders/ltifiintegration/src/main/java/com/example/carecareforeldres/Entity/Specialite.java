package com.example.carecareforeldres.Entity;

public enum Specialite {
    PSYCHIATRIE,PEDIATRIE,CARDIOLOGIE,DERMATOLOGIE,ANESTHESIOLOGIE,CHIRURGIE,GENERAL
}
