package com.example.carecareforeldres.Entity;

public enum TypeBadge {
    GOLD,SILVER,BRONZE
}
