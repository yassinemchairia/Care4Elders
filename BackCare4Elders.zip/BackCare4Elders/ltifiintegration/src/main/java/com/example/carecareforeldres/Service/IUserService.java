package com.example.carecareforeldres.Service;

import com.example.carecareforeldres.Entity.User;

public interface IUserService {
    User getUserById(Integer id);
}
