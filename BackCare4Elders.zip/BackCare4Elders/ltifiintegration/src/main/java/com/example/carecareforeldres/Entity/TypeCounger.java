package com.example.carecareforeldres.Entity;

public enum TypeCounger {
    COUGER_PARENTALE,
    COUNGER_MATERNITE ,
    COUNGER_SABBATIQUE,
    COUNGER_MALADIE

}
