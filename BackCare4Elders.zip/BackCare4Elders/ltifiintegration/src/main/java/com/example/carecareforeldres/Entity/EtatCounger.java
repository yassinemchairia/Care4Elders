package com.example.carecareforeldres.Entity;

public enum EtatCounger {
    EN_COUR,
    ACCEPTEE,
    REFUSER
}
