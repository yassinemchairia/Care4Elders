package com.example.carecareforeldres.Repository;

import com.example.carecareforeldres.Entity.Ambilancier;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AmbilancierRepository extends JpaRepository<Ambilancier,Integer> {
}
