package com.example.carecareforeldres.Entity;

public enum TypePlat {
    Entree,Principale,Dessert
}
