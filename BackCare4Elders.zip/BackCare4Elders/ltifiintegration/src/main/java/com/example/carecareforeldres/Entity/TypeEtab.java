package com.example.carecareforeldres.Entity;

public enum TypeEtab {
    HOPITAL,CLINIQUE

}
