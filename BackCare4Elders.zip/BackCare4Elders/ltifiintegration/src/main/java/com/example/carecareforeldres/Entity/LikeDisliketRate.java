package com.example.carecareforeldres.Entity;

public enum LikeDisliketRate {
    LIKE,
    DISLIKE,
}
