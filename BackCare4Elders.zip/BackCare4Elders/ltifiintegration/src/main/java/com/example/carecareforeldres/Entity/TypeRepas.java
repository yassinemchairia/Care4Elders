package com.example.carecareforeldres.Entity;

public enum TypeRepas {
    PETIT_DEJEUNER,
    DEJEUNER
    ,DINER
    ,ALL

    }
