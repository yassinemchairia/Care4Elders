package com.example.carecareforeldres.Entity;

public enum TypeEnum {
    // aa,bb,cc,dd,ee;
    Sportifs ,Loisirs ,Sante ,Culturels_Artistiques
}
