package com.example.carecareforeldres.Entity;

public enum EtatAmb {
    FONCTIONNELLE,PANNE,MAINTENANCE

}
