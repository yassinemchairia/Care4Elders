package com.example.carecareforeldres.Entity;

public enum EtatActivite {
        EN_ATTENTE,
        ACCEPTE,
        REFUSE

}
