package com.example.carecareforeldres.Repository;

import com.example.carecareforeldres.Entity.Achievement;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AchievementRepository extends JpaRepository<Achievement,Long> {
}
