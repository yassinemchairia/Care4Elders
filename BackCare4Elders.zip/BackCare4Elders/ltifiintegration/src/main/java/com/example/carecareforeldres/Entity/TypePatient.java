package com.example.carecareforeldres.Entity;

public enum TypePatient {
    NORMAL,URGENT,DECEDE
}
