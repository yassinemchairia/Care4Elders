package com.example.carecareforeldres.Service;

public interface IServiceLikeDislike {
}
