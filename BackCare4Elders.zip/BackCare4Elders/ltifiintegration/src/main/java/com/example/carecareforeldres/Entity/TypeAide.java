package com.example.carecareforeldres.Entity;

public enum TypeAide {
    MONEY,
    CLOTHES,
    VOLUNTEER_HOURS,
    MEDICAMENT,
    ADDITIONAL_SPACE
}
