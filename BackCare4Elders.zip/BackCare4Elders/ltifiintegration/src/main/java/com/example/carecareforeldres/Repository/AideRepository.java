package com.example.carecareforeldres.Repository;

import com.example.carecareforeldres.Entity.Aide;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AideRepository extends JpaRepository<Aide,Long> {
}
