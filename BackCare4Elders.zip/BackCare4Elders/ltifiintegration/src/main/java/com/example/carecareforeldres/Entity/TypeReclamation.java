package com.example.carecareforeldres.Entity;

public enum TypeReclamation {SERVICE, QUALITE_PRODUIT, LIVRAISON, FACTURATION, RETOUR, AUTRE;}
