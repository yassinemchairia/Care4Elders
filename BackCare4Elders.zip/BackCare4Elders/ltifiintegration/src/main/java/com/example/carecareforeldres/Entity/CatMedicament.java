package com.example.carecareforeldres.Entity;

public enum CatMedicament {
    ANALGESIQUE,
    ANTIBIOTIQUE,
    ANTIVIRAL,
    ANTIINFLAMMATOIRE,
    ANTIDEPRESSEUR,
    ANTIPSYCHOTIQUE,
    HYPOTENSEUR,
    DIURETIQUE,
    VACCIN
}
