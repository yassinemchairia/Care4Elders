package com.example.carecareforeldres.token;

public enum TokenType {
  BEARER
}
