package com.example.carecareforeldres.Entity;

public enum TypeService {
    MEDICAL_CARE,
    PSYCHOLOGICAL_COUNSELING,
    FOOD_SERVICES,
}
