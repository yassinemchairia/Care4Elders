package com.example.carecareforeldres.Entity;

public enum TypeRole {
    USER, MEDECIN,AMBILANCIER,INFERMIER,PATIENT,VISITEUR,ADMIN,DONATEUR,HOMELESS,ORGANISATEUR,CUISINIER
}
    