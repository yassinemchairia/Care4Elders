package com.example.carecareforeldres;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarecareforEldresApplicationTests {

    @Test
    void contextLoads() {
    }

}
